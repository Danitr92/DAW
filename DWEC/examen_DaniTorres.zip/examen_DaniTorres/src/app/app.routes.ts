import { Routes } from '@angular/router';
import { ProductListComponent } from './pages/product-list/product-list.component';
import { ProductViewComponent } from './pages/product-view/product-view.component';

export const routes: Routes = [
    { path: "", pathMatch: "full", redirectTo: "products"},
    { path: "products", component: ProductListComponent},
    { path: "product/:_id", component: ProductViewComponent},
    {path: "**", redirectTo: "products"} 
];
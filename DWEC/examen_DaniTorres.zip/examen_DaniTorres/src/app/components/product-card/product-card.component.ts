import { Component, Input } from '@angular/core';
import { Product } from '../../interfaces/product';
import { RouterLink } from '@angular/router';
import { BotoneraComponent } from '../botonera/botonera.component';

@Component({
  selector: 'app-product-card',
  standalone: true,
  imports: [BotoneraComponent],
  templateUrl: './product-card.component.html',
  styleUrl: './product-card.component.css'
})
export class ProductCardComponent {
  @Input() miProduct!: Product;

  constructor() {}

}

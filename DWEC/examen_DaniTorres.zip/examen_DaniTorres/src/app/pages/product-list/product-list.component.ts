import { Component, inject } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { ProductCardComponent } from '../../components/product-card/product-card.component';
import { Product } from '../../interfaces/product';
import { ProductService } from '../../services/product.service';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [ProductCardComponent],
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent {

  arrProducts: Product[] = []
  productService = inject(ProductService);

  async ngOnInit(): Promise<void> {
    try {
      this.arrProducts = await this.productService.getAllWithPromises();
      console.log('arrUsers:', this.arrProducts);
    }
    catch (err) {
      console.log('Error al conectar a la API: '+err)
    }
    
  }

}

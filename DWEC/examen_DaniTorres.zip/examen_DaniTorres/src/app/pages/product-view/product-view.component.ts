import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { ProductService } from '../../services/product.service';
import { ActivatedRoute } from '@angular/router';
import { Product } from '../../interfaces/product';

@Component({
  selector: 'app-product-view',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './product-view.component.html',
  styleUrl: './product-view.component.css'
})
export class ProductViewComponent {
  
  userService = inject(ProductService);
  activatedRoute = inject(ActivatedRoute);

  miProduct!: Product;

  ngOnInit(): void{
    this.activatedRoute.params.subscribe(async (params: any) => {
      let _id: string = params._id as string;

      try {
        this.miProduct = await this.userService.getById(_id);
        console.log("Usuario recibido:", this.miProduct);
      } catch (err) {
        console.log("Error al llamar a la API: " + err);
      }
    });
  }
  

}

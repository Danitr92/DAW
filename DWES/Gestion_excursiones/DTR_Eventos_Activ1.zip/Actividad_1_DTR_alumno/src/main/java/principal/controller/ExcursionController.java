package principal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import principal.modelo.dao.ExcursionDao;
import principal.modelo.javabean.Excursion;

@Controller
@RequestMapping("/excursiones")
public class ExcursionController {
	@Autowired
	private ExcursionDao edao;
	
	//metodo para editar excursiones y muestra un mensaje en el home de si se ha hecho bien
	@PostMapping("/editar/{idExcursion}")
	public String procFormEdicion(@PathVariable long idExcursion, Excursion excursion, RedirectAttributes ratt) {
		excursion.setIdExcursion(idExcursion);
		
		if (edao.updateOne(excursion) == 1)
			ratt.addFlashAttribute("mensaje", "La excursion ha sido editada correctamente");
		else
			ratt.addFlashAttribute("mensaje", "La excursion no se ha podido editar");
		
		return "redirect:/"; 
	}
	
	//metodo para ir al formulario de edicion
	@GetMapping("/editar/{idExcursion}")
	public String procModificar(Model model, @PathVariable long idExcursion) {
		
		Excursion excursion = edao.findById(idExcursion);
		if (excursion == null) {
			model.addAttribute("mensaje", "La excursion no existe, alguien lo ha borrado");
			return "forward:/";
		}
		model.addAttribute("excursion", excursion);
		return "formEdicionExcursion";
	}
	
	//metodo para crear nuevas excursiones devolviendo mensaje en el home también
	@PostMapping("/alta")
	public String procFormAlta(Excursion excursion, RedirectAttributes ratt) {
		if (edao.insertOne(excursion) == 1)
			ratt.addFlashAttribute("mensaje", "Excursión creada");
		else
			ratt.addFlashAttribute("mensaje", "Excursión no creada");
		
		
		return "redirect:/";
	}
	
	//metodo para ir al formulario de nuevas
	@GetMapping("/alta")
	public String procAlta() {
		return "formAltaExcursion";
	}
	
	//manda al formulario de estado con todas las excursiones
	@GetMapping("/estado")
	public String procEstado(Model model) {
		model.addAttribute("excursiones", edao.findAll());
		return "formEstado";
	}

	//manda al form de destacado con todas las excursiones, alli filtro con un if las que si estan destacadas.
	@GetMapping("/destacado")
	public String procDestacado(Model model) {
		model.addAttribute("excursiones", edao.findAll());
		return "formDestacado";
	}
	
	//manda al form de terminado con todas las excursiones, alli filtro con un if las que si estan terminadas.
	@GetMapping("/terminado")
	public String procTerminado(Model model) {
		model.addAttribute("excursiones", edao.findAll());
		return "formTerminado";
	}
	
	//metodo para buscar excursiones por descripcion, cogiendo las que cumplen
	@GetMapping("/buscar")
	public String procBuscar(@RequestParam("query") String query, Model model) {
	    List<Excursion> excursiones = edao.findByDescripcionContainingIgnoreCase(query);
	    model.addAttribute("excursiones", excursiones);
	    return "formBuscar";
	}

	//elimino excursiones por identificativo
	@GetMapping("/eliminar/{idExcursion}")
	public String eliminar(Model model, @PathVariable long idExcursion) {
		
		int filas = edao.deleteOne(idExcursion);
		
		if(filas == 1)
			model.addAttribute("mensaje", "Excursion eliminada");
		else
			model.addAttribute("mensaje", "Excursion no eliminada");		
		
		return "forward:/";
	}
		
		
	//para ver detalles de una excursion
	@GetMapping("/detalle/{idExcursion}")
	public String VerDetalle(Model model, @PathVariable long idExcursion) {
		
		Excursion excursion = edao.findById(idExcursion);
		
		model.addAttribute("excursion", excursion);
		
		
		return "VerDetalle";

	}
	
}

package principal.modelo.dao;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;
import principal.modelo.javabean.Excursion;



@Repository 
public class ExcursionDaoImplList implements ExcursionDao{

	private List<Excursion> lista;
	
	public ExcursionDaoImplList() {
		lista = new ArrayList<>();
		cargarDatos();
	}
	
	private void cargarDatos() {
		lista.add(new Excursion(1001, "Viaje de Madrid a Valencia", "Madrid", "Valencia", new Date(), 4, "CREADO", "Si", 20, 5, 189, "https://m.media-amazon.com/images/I/41UcMHEJedL._AC_UF894,1000_QL80_.jpg", new Date()));
		lista.add(new Excursion(1002, "Viaje de Madrid a Barcelona", "Madrid", "Barcelona", new Date(),5, "CREADO", "No", 15, 4, 240, "https://m.media-amazon.com/images/I/41UcMHEJedL._AC_UF894,1000_QL80_.jpg", new Date()));
		lista.add(new Excursion(1003, "Viaje de Madrid a Oporto", "Madrid", "Oporto", new Date(), 7, "CANCELADO", "Si", 32, 8, 350, "https://m.media-amazon.com/images/I/41UcMHEJedL._AC_UF894,1000_QL80_.jpg", new Date()));
		lista.add(new Excursion(1004, "Viaje de Madrid a Segovia", "Madrid", "Segovia", new Date(), 3, "TERMINADO", "No", 12, 4, 120, "https://m.media-amazon.com/images/I/41UcMHEJedL._AC_UF894,1000_QL80_.jpg", new Date()));
		lista.add(new Excursion(1005, "Viaje de Madrid a Cádiz", "Madrid", "Cádiz", new Date(), 5, "CANCELADO", "Si", 16, 6, 190, "https://m.media-amazon.com/images/I/41UcMHEJedL._AC_UF894,1000_QL80_.jpg", new Date()));
		lista.add(new Excursion(1006, "Viaje de Madrid a Sevilla", "Madrid", "Sevilla", new Date(), 3, "TERMINADO", "No", 10, 5, 110, "https://m.media-amazon.com/images/I/41UcMHEJedL._AC_UF894,1000_QL80_.jpg", new Date()));

	}

	
	//aqui busco excursiones por su identificaditvo, si existe la devuelvo sino null
	@Override
	public Excursion findById(long idExcursion) {
		for (Excursion ele: lista) {
			if(ele.getIdExcursion() == idExcursion)
				return ele;
		}
		return null;
	}
	
	//aqui añado escursiones si no existen ya
	@Override
	public int insertOne(Excursion excursion) {
		if (lista.contains(excursion))
			return 0;
		return lista.add(excursion) ? 1 : 0;
	}

	//actualizo una excursion que ya exista y devuelvo 1 si esta bien
	@Override
	public int updateOne(Excursion excursion) {
		int pos = lista.indexOf(excursion);
		
		if (pos == -1)
			return 0;
		return (lista.set(pos, excursion) != null) ? 1 : 0;
	}
	
	//elimino y devuelvo 1 si se hace bien
	@Override
	public int deleteOne(Excursion excursion) {
		return lista.remove(excursion) ? 1 : 0;
	}
	
	//elimino a traves de su id
	@Override
	public int deleteOne(long idExcursion) {
		Excursion excursion = findById(idExcursion);
		return deleteOne(excursion);
	}
	
	//devuelve todas las excursiones
	@Override
	public List<Excursion> findAll() {
		return lista;
	}

	//busco excursiones por su descripcion ignorando mayusculas
	@Override
	public List<Excursion> findByDescripcionContainingIgnoreCase(String descripcion) {
	    if (descripcion == null || descripcion.isEmpty()) {
	        return null;
	    }
	    
	    return lista.stream()
	        .filter(excursion -> excursion.getDescripcion().toLowerCase().contains(descripcion.toLowerCase()))
	        .collect(Collectors.toList());
	}
	
	
	
	
}
package cajeroweb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import cajeroweb.modelo.dao.CuentaDao;
import cajeroweb.modelo.entidades.Cuenta;

@Controller
public class HomeController {

    @Autowired
    private CuentaDao cdao;

    //cualquiera de estas rutas me lleva a la pagina home
    @GetMapping({"","/","/home"})
	public String inicio() {
		return "home";
	}

    // si la cuenta existe me lleva al menu html y le pasa la cuenta
    @GetMapping("/acceder")
    public String acceder(@RequestParam("idCuenta") int idCuenta, Model model) {
        Cuenta cuenta = cdao.findById(idCuenta);
        if (cuenta != null) {
            model.addAttribute("cuenta", cuenta); 
            return "menu"; 
        } else {
            model.addAttribute("mensaje", "Cuenta no encontrada.");
            return "home"; 
        }
    }
}
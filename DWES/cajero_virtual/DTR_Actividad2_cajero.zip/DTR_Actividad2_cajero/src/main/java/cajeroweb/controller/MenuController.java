package cajeroweb.controller;

import cajeroweb.modelo.dao.CuentaDao;
import cajeroweb.modelo.dao.MovimientoDao;
import cajeroweb.modelo.entidades.Cuenta;
import cajeroweb.modelo.entidades.Movimiento;
import jakarta.servlet.http.HttpSession;
import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Date;
import java.util.List;

@Controller
public class MenuController {

    @Autowired
    private CuentaDao cdao;

    @Autowired
    private MovimientoDao mdao;

    // muestra la pagina menu si existe la cuenta, sino vamos a home
    @GetMapping("/menu")
    public String mostrarMenu(@RequestParam("idCuenta") int idCuenta, Model model) {
        Cuenta cuenta = cdao.findById(idCuenta);
        if (cuenta != null) {
            model.addAttribute("cuenta", cuenta);
            return "menu";  
        } else {
            model.addAttribute("mensaje", "Cuenta no encontrada.");
            return "home";  
        }
    }

    // aqui realizamos el ingreso o extraccion, si la cantidad es mayor que el saldo lanzo el error
    // si se realiza la operacion guardo el saldo nuevo y creo un nuevo movimiento
    @PostMapping("/realizarMovimiento")
    @Transactional
    public String realizarMovimiento(@RequestParam("idCuenta") int idCuenta, @RequestParam("cantidad") double cantidad, @RequestParam("operacion") String operacion, Model model) {

        Cuenta cuenta = cdao.findById(idCuenta);

        if (cuenta != null) {
            if ("EXTRAER".equals(operacion) && cantidad > cuenta.getSaldo()) {
                model.addAttribute("mensajeError", "Saldo insuficiente para realizar la extracción.");
                model.addAttribute("cuenta", cuenta); 
                return "menu"; 
            }
            if ("INGRESAR".equals(operacion)) {
                cuenta.setSaldo(cuenta.getSaldo() + cantidad);
            } else if ("EXTRAER".equals(operacion)) {
                cuenta.setSaldo(cuenta.getSaldo() - cantidad);
            }

            cdao.guardarCuenta(cuenta); 

            Movimiento movimiento = new Movimiento();
            movimiento.setCuenta(cuenta);
            movimiento.setCantidad(cantidad);
            movimiento.setOperacion(operacion);
            movimiento.setFecha(new Date());
            mdao.guardarMovimiento(movimiento); 

            model.addAttribute("cuenta", cuenta);
            	return "menu"; 
        	} 
            else {
            	model.addAttribute("mensaje", "Cuenta no encontrada.");
            	return "menu";
            }
    }

    // vamos al html movimientos para ver los movimientos guardados, si falla mantenemos menu
    @GetMapping("/verMovimientos")
    public String verMovimientos(@RequestParam("idCuenta") int idCuenta, Model model) {
        Cuenta cuenta = cdao.findById(idCuenta);
        if (cuenta != null) {
            List<Movimiento> movimientos = mdao.findByCuentaId(idCuenta);
            model.addAttribute("movimientos", movimientos);
            model.addAttribute("cuenta", cuenta);
            return "movimientos"; 
        } else {
            model.addAttribute("mensaje", "Cuenta no encontrada.");
            return "menu"; 
        }
    }

    // cerramos sesion y volvemos al home html
    @PostMapping("/cerrarSesion")
    public String cerrarSesion(HttpSession sesion) {
		sesion.removeAttribute("cuenta");
		sesion.invalidate();
        return "home"; 
    }
    
   
    
}
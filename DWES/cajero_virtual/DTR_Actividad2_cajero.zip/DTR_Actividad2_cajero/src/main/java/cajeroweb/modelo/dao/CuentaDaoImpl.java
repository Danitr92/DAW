package cajeroweb.modelo.dao;

import cajeroweb.modelo.dao.CuentaDao;
import cajeroweb.modelo.entidades.Cuenta;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

import org.springframework.stereotype.Repository;

@Repository
public class CuentaDaoImpl implements CuentaDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Cuenta findById(int idCuenta) {
        return entityManager.find(Cuenta.class, idCuenta);
    }

    //uso el persist y merge, con el transactional, para actualizar la cuenta nueva sin que casque
    @Override
    @Transactional
    public void guardarCuenta(Cuenta cuenta) {
    	 if (cuenta.getIdCuenta() == 0) {
             entityManager.persist(cuenta); 
         } else {
             if (!entityManager.contains(cuenta)) {
                 cuenta = entityManager.merge(cuenta);
             }
         }
    }
}
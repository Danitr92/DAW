package cajeroweb.modelo.dao;

import cajeroweb.modelo.entidades.Cuenta;
import cajeroweb.modelo.repository.CuentaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class CuentaDaoImpl implements CuentaDao {

    @Autowired
    private CuentaRepository crepo;

    @Override
    public Cuenta findById(int idCuenta) {
        return crepo.findByIdCuenta(idCuenta);  
    }

    @Override
    public void guardarCuenta(Cuenta cuenta) {
        crepo.save(cuenta);  
    }
}
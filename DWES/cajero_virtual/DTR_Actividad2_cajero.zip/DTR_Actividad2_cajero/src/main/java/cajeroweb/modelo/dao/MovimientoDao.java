package cajeroweb.modelo.dao;

import cajeroweb.modelo.entidades.Movimiento;
import java.util.List;

public interface MovimientoDao {

    List<Movimiento> findByCuentaId(int idCuenta);

    void guardarMovimiento(Movimiento movimiento);
}
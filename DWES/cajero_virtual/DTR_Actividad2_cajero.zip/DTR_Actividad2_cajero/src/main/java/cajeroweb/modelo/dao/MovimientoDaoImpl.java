package cajeroweb.modelo.dao;

import cajeroweb.modelo.dao.MovimientoDao;
import cajeroweb.modelo.entidades.Movimiento;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class MovimientoDaoImpl implements MovimientoDao {

    @PersistenceContext
    private EntityManager entityManager;

    //hacemos una consulta a la tabla de movimientos con el idCuenta
    @Override
    public List<Movimiento> findByCuentaId(int idCuenta) {
        return entityManager.createQuery("SELECT m FROM Movimiento m WHERE m.cuenta.idCuenta = :idCuenta", Movimiento.class)
                            .setParameter("idCuenta", idCuenta)
                            .getResultList();
    }

    // guardamos el movimiento en la bbdd
    @Override
    public void guardarMovimiento(Movimiento movimiento) {
        entityManager.persist(movimiento);  
    }
}

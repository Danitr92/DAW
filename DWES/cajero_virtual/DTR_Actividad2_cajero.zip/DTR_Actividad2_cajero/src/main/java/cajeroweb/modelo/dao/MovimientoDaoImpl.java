package cajeroweb.modelo.dao;

import cajeroweb.modelo.entidades.Movimiento;
import cajeroweb.modelo.repository.MovimientoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class MovimientoDaoImpl implements MovimientoDao {

    @Autowired
    private MovimientoRepository mrepo;

    @Override
    public List<Movimiento> findByCuentaId(int idCuenta) {
        return mrepo.findByCuentaIdCuenta(idCuenta);  
    }

    @Override
    public void guardarMovimiento(Movimiento movimiento) {
        mrepo.save(movimiento); 
    }
}
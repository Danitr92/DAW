package cajeroweb.controller;

import cajeroweb.modelo.dao.CuentaDao;
import cajeroweb.modelo.dao.MovimientoDao;
import cajeroweb.modelo.entidades.Cuenta;
import cajeroweb.modelo.entidades.Movimiento;
import jakarta.servlet.http.HttpSession;
import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Date;
import java.util.List;

@Controller
public class MenuController {

    @Autowired
    private CuentaDao cdao;

    @Autowired
    private MovimientoDao mdao;

    // muestra la pagina menu si existe la cuenta, sino vamos a home
    @GetMapping("/menu")
    public String mostrarMenu(@RequestParam("idCuenta") int idCuenta, Model model) {
        Cuenta cuenta = cdao.findById(idCuenta);
        if (cuenta != null) {
            model.addAttribute("cuenta", cuenta);
            return "menu";  
        } else {
            model.addAttribute("mensaje", "Cuenta no encontrada.");
            return "home";  
        }
    }

    
    // aqui realizamos el ingreso o extraccion, si la cantidad es mayor que el saldo lanzo el error
    // si se realiza la operacion guardo el saldo nuevo y creo un nuevo movimiento
    @PostMapping("/realizarMovimiento")
    public String realizarMovimiento(@RequestParam("idCuenta") int idCuenta, @RequestParam("cantidad") double cantidad, @RequestParam("operacion") String operacion, Model model) {

        Cuenta cuenta = cdao.findById(idCuenta);

        if (cuenta != null) {
            if ("EXTRAER".equals(operacion) && cantidad > cuenta.getSaldo()) {
                model.addAttribute("mensajeError", "Saldo insuficiente para realizar la extracción.");
                model.addAttribute("cuenta", cuenta); 
                return "menu"; 
            }
            if ("INGRESAR".equals(operacion)) {
                cuenta.setSaldo(cuenta.getSaldo() + cantidad);
            } else if ("EXTRAER".equals(operacion)) {
                cuenta.setSaldo(cuenta.getSaldo() - cantidad);
            }

            cdao.guardarCuenta(cuenta); 

            Movimiento movimiento = new Movimiento();
            movimiento.setCuenta(cuenta);
            movimiento.setCantidad(cantidad);
            movimiento.setOperacion(operacion);
            movimiento.setFecha(new Date());
            mdao.guardarMovimiento(movimiento); 

            model.addAttribute("cuenta", cuenta);
            	return "menu"; 
        	} 
            else {
            	model.addAttribute("mensaje", "Cuenta no encontrada.");
            	return "menu";
            }
    }

    // vamos al html movimientos para ver los movimientos guardados, si fallara mantenemos menu
    @GetMapping("/verMovimientos")
    public String verMovimientos(@RequestParam("idCuenta") int idCuenta, Model model) {
        Cuenta cuenta = cdao.findById(idCuenta);
        if (cuenta != null) {
            List<Movimiento> movimientos = mdao.findByCuentaId(idCuenta);
            model.addAttribute("movimientos", movimientos);
            model.addAttribute("cuenta", cuenta);
            return "movimientos"; 
        } else {
            model.addAttribute("mensaje", "Cuenta no encontrada.");
            return "menu"; 
        }
    }

    // cerramos sesion y volvemos al home html
    @PostMapping("/cerrarSesion")
    public String cerrarSesion(HttpSession sesion) {
		sesion.removeAttribute("cuenta");
		sesion.invalidate();
        return "home"; 
    }
    
    //muestra la vista de transferencias
    @GetMapping("/transferencia")
    public String mostrarTransferencia(@RequestParam("idCuenta") int idCuenta, Model model) {
        Cuenta cuenta = cdao.findById(idCuenta);
        model.addAttribute("cuenta", cuenta);
        return "transferencia"; 
    }
    
    
    //repetimos operaciones pero guardando en distintos movimientos, de origen y destino con la operacion de transferencia
    //salta error si la cuenta de destino no existe, si se envia a uno mismo y si la cantidad es mayor al saldo
    @PostMapping("/realizarTransfer")
    public String realizarTransferencia(@RequestParam("idCuentaOrigen") int idCuentaOrigen, @RequestParam("idCuentaDestino") int idCuentaDestino, @RequestParam("cantidad") double cantidad, Model model) {

        Cuenta cuentaOrigen = cdao.findById(idCuentaOrigen);
        Cuenta cuentaDestino = cdao.findById(idCuentaDestino);

        if (cuentaDestino != null) {
            if (cantidad > cuentaOrigen.getSaldo()) {
                model.addAttribute("mensajeError", "Saldo insuficiente.");
                model.addAttribute("cuenta", cuentaOrigen); 
                return "transferencia";
            }
            
            if (cuentaOrigen == cuentaDestino) {
                model.addAttribute("mensajeError", "No puedes enviar a tu misma cuenta.");
                model.addAttribute("cuenta", cuentaOrigen); 
                return "transferencia";
            }

            cuentaOrigen.setSaldo(cuentaOrigen.getSaldo() - cantidad);
            cuentaDestino.setSaldo(cuentaDestino.getSaldo() + cantidad);
            cdao.guardarCuenta(cuentaOrigen);
            cdao.guardarCuenta(cuentaDestino);

            Movimiento movimientoOrigen = new Movimiento();
            movimientoOrigen.setCuenta(cuentaOrigen);
            movimientoOrigen.setCantidad(cantidad);
            movimientoOrigen.setOperacion("EXTRACCIÓN POR TRANSFERENCIA");
            movimientoOrigen.setFecha(new Date());
            mdao.guardarMovimiento(movimientoOrigen);

            Movimiento movimientoDestino = new Movimiento();
            movimientoDestino.setCuenta(cuentaDestino);
            movimientoDestino.setCantidad(cantidad);
            movimientoDestino.setOperacion("INGRESO POR TRANSFERENCIA");
            movimientoDestino.setFecha(new Date());
            mdao.guardarMovimiento(movimientoDestino);

            model.addAttribute("cuenta", cuentaOrigen);
            return "transferencia"; 
        } else {
            model.addAttribute("mensajeError", "La cuenta de destino no existe.");
            model.addAttribute("cuenta", cuentaOrigen); 
            return "transferencia";
        }
    }
    
}
    
